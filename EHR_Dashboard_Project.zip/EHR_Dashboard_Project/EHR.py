import uuid
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="EHR Patient Readmission Dashboard", layout="wide")

WIDGET_TYPES = [
    "Metric Card",
    "Readmission Breakdown (Bar)",
    "Risk Analysis (Scatter)",
    "Trend Line",
    "Patient Cohort Table",
    "Clinical Notes (Text)"
]

AGG_FUNCS = {
    "Total Patients (Count)": "count",
    "Readmission Rate (Mean)": "mean",
    "Average Length of Stay (Mean)": "mean",
    "Max Length of Stay": "max",
    "Total Risk Score (Sum)": "sum"
}

# Initialize session state
if "widgets" not in st.session_state:
    st.session_state.widgets = []
if "data" not in st.session_state:
    st.session_state.data = None
if "cols_per_row" not in st.session_state:
    st.session_state.cols_per_row = 2

@st.cache_data
def generate_ehr_sample_data() -> pd.DataFrame:
    """Generates synthetic Electronic Health Records (EHR) data for testing."""
    rng = np.random.default_rng(42)
    n = 300
    
    # Generate realistic EHR variables
    age = rng.integers(18, 90, n)
    los = rng.integers(1, 15, n)  # Length of stay in days
    comorbidities = rng.integers(0, 5, n)
    
    # Readmission probability based loosely on age, LOS, and comorbidities
    base_prob = 0.1 + (los * 0.02) + (comorbidities * 0.04) + (age * 0.001)
    base_prob = np.clip(base_prob, 0.05, 0.85)
    readmitted = rng.binomial(1, base_prob)
    
    return pd.DataFrame({
        "Patient_ID": [f"PT-{i:05d}" for i in range(1000, 1000 + n)],
        "Admission_Date": pd.date_range("2025-01-01", periods=n, freq="D"),
        "Age": age,
        "Gender": rng.choice(["Male", "Female", "Other"], n, p=[0.48, 0.50, 0.02]),
        "Admission_Type": rng.choice(["Emergency", "Elective", "Urgent"], n, p=[0.55, 0.30, 0.15]),
        "Primary_Diagnosis": rng.choice(["Cardiology", "Metabolic", "Respiratory", "Neurology", "Infectious"], n),
        "Length_of_Stay_Days": los,
        "Comorbidity_Index": comorbidities,
        "Readmitted": readmitted  # 1 = Yes, 0 = No
    })

def add_widget(kind: str) -> None:
    st.session_state.widgets.append({
        "id": uuid.uuid4().hex[:8],
        "type": kind,
        "title": f"{kind} {len(st.session_state.widgets) + 1}",
        "cfg": {},
    })

def move_widget(idx: int, delta: int) -> None:
    new_idx = idx + delta
    if 0 <= new_idx < len(st.session_state.widgets):
        ws = st.session_state.widgets
        ws[idx], ws[new_idx] = ws[new_idx], ws[idx]

def delete_widget(idx: int) -> None:
    st.session_state.widgets.pop(idx)

def render_widget(w: dict, df: pd.DataFrame | None) -> None:
    kind, cfg, title = w["type"], w["cfg"], w["title"]
    
    if kind == "Clinical Notes (Text)":
        st.markdown(cfg.get("text", "##### Clinical Notes\n*No notes configured yet. Use the sidebar editor.*"))
        return
        
    if df is None:
        st.warning("Please load EHR data source to preview this widget.")
        return

    try:
        if kind == "Metric Card":
            col = cfg.get("column")
            agg_label = cfg.get("agg", "Total Patients (Count)")
            agg_func = AGG_FUNCS.get(agg_label, "count")
            
            if not col or col not in df.columns:      
                st.info("Configure clinical numeric column in sidebar.")      
                return      
                  
            value = getattr(df[col], agg_func)()      
            if agg_func == "mean" and (col == "Readmitted" or "rate" in col.lower() or "rate" in title.lower()):
                # Format readmission rate as a percentage if applicable
                formatted_value = f"{value * 100:.1f}%"
            elif isinstance(value, (float, np.floating)):
                formatted_value = f"{value:,.2f}"
            else:
                formatted_value = f"{value:,}"
                
            st.metric(label=title, value=formatted_value, help=f"{agg_label} computed on {col}")      
            
        elif kind in ("Readmission Breakdown (Bar)", "Risk Analysis (Scatter)", "Trend Line"):      
            x, y = cfg.get("x"), cfg.get("y")      
            color = cfg.get("color", "Readmitted")      
            
            if not x or not y or x not in df.columns or y not in df.columns:      
                st.info("Configure chart mapping (X and Y axis) in sidebar.")      
                return      
                
            color_arg = color if (color and color != "None" and color in df.columns) else None 
                 
            if kind == "Trend Line":      
                fig = px.line(df.sort_values(by=x), x=x, y=y, color=color_arg, title=title)      
            elif kind == "Readmission Breakdown (Bar)":      
                fig = px.bar(df, x=x, y=y, color=color_arg, title=title, barmode="group")      
            else:      
                fig = px.scatter(df, x=x, y=y, color=color_arg, title=title, opacity=0.7)      
                
            fig.update_layout(margin=dict(l=10, r=10, t=40, b=10), height=320)      
            st.plotly_chart(fig, use_container_width=True)      
            
        elif kind == "Patient Cohort Table":      
            st.markdown(f"*{title}*")      
            st.dataframe(df.head(cfg.get("rows", 10)), use_container_width=True)

    except Exception as e:
        st.error(f"EHR Render Error: {e}")

def widget_editor(w: dict, df: pd.DataFrame | None, idx: int) -> None:
    wid = w["id"]
    w["title"] = st.text_input("Widget Title", w["title"], key=f"title_{wid}")
    cfg = w["cfg"]

    if df is not None:
        numeric = df.select_dtypes(include="number").columns.tolist()
        all_cols = df.columns.tolist()

        def pick(label, options, key, current):      
            idx_ = options.index(current) if current in options else 0      
            return st.selectbox(label, options, index=idx_, key=key)      
              
        if w["type"] == "Metric Card":      
            if numeric:
                cfg["column"] = pick("Target Clinical Column", numeric, f"col_{wid}", cfg.get("column", numeric[0]))      
                cfg["agg"] = pick("Aggregation Method", list(AGG_FUNCS.keys()), f"agg_{wid}", cfg.get("agg", "Total Patients (Count)"))      
            else:
                st.error("No numeric metrics discovered in data profile.")
            
        elif w["type"] in ("Readmission Breakdown (Bar)", "Risk Analysis (Scatter)", "Trend Line"):      
            cfg["x"] = pick("X Axis Variable", all_cols, f"x_{wid}", cfg.get("x", all_cols[0]))      
            if numeric:
                cfg["y"] = pick("Y Axis Variable (Numeric)", numeric, f"y_{wid}", cfg.get("y", numeric[0]))      
            else:
                st.error("Y-Axis needs a numeric profiling column.")
            cfg["color"] = pick("Color Grouping Stratum", ["None"] + all_cols, f"color_{wid}", cfg.get("color", "Readmitted" if "Readmitted" in all_cols else "None"))      

        elif w["type"] == "Patient Cohort Table":      
            cfg["rows"] = st.slider("Max Clinical Rows to Display", 5, 50, cfg.get("rows", 10), key=f"row_{wid}")

    if w["type"] == "Clinical Notes (Text)":
        cfg["text"] = st.text_area(
            "Markdown / Clinical Interpretations",
            cfg.get("text", "##### Clinical Findings Header \n\n* Highlight insights on high risk readmission categories here..."),
            key=f"text_{wid}",
            height=120,
        )
        
    c1, c2, c3 = st.columns(3)
    c1.button("⬆️", key=f"up_{wid}", on_click=move_widget, args=(idx, -1), use_container_width=True)
    c2.button("⬇️", key=f"down_{wid}", on_click=move_widget, args=(idx, 1), use_container_width=True)
    c3.button("🗑️", key=f"del_{wid}", on_click=delete_widget, args=(idx,), use_container_width=True)


# --- SIDEBAR CONTROL PANEL ---
with st.sidebar:
    st.title("🏥 EHR Analytics Designer")
    
    st.subheader("1. Patient Data Stream")
    source = st.radio("Source Selector", ["Interactive Synthetic EHR", "Upload Hospital CSV File"], horizontal=True, label_visibility="collapsed")
    
    if source == "Interactive Synthetic EHR":
        st.session_state.data = generate_ehr_sample_data()
    else:
        up = st.file_uploader("Upload Patient EHR CSV", type=["csv"])
        if up is not None:
            try:
                st.session_state.data = pd.read_csv(up)
            except Exception as e:
                st.sidebar.error(f"Error reading file: {e}")
        else:
            if getattr(st.session_state, "_prev_source", None) == "Interactive Synthetic EHR":
                st.session_state.data = None
                
    st.session_state._prev_source = source

    df = st.session_state.data
    if df is not None:
        st.caption(f"📊 Dataset Size: *{len(df):,} patient records* × *{len(df.columns)} metrics*")
        
    st.divider()
    st.subheader("2. Grid Layout Management")
    st.session_state.cols_per_row = st.slider("Max Columns Per Dashboard Row", 1, 4, st.session_state.cols_per_row)

    st.divider()
    st.subheader("3. Add Clinical Insight Component")
    new_kind = st.selectbox("Select Component Profile", WIDGET_TYPES, label_visibility="collapsed")
    st.button("Insert Component", on_click=add_widget, args=(new_kind,), use_container_width=True, type="primary")

    if st.session_state.widgets:
        st.divider()
        st.subheader(f"4. Component Configuration Matrix ({len(st.session_state.widgets)})")
        for i, w in enumerate(st.session_state.widgets):
            with st.expander(f"{i+1}. [{w['type']}] {w['title']}"):
                widget_editor(w, df, i)


# --- MAIN INTERFACE DISPLAY ---
st.title("📋 Electronic Health Records (EHR) Readmission Prediction Dashboard")

if not st.session_state.widgets:
    st.info("💡 *Welcome Clinician/Data Scientist!* Please inject components from the sidebar control hub to construct your custom real-time patient risk analysis canvas.")
    if st.session_state.data is not None:
        st.subheader("Raw Structural Sample of EHR Patient Logs (Top 10 Rows)")
        st.dataframe(st.session_state.data.head(10), use_container_width=True)
else:
    n_cols = st.session_state.cols_per_row
    widgets = st.session_state.widgets
    
    for row_start in range(0, len(widgets), n_cols):
        row_widgets = widgets[row_start:row_start + n_cols]
        cols = st.columns(n_cols)
        
        for col, w in zip(cols, row_widgets):
            with col:
                with st.container(border=True):
                    render_widget(w, st.session_state.data)