# Electronic Health Records (EHR) Readmission Analytics Dashboard

## Overview

This project is an interactive healthcare dashboard developed using **Python** and **Streamlit**. It helps users analyze Electronic Health Records (EHR) by displaying patient information, readmission trends, and key healthcare metrics through interactive charts and tables.

## Features

* Upload and analyze EHR CSV files
* Built-in sample dataset for testing
* Interactive KPI metric cards
* Bar, Scatter, and Trend charts
* Patient data table
* Add and customize dashboard widgets
* Simple and user-friendly interface

## Technologies Used

* Python
* Streamlit
* Pandas
* NumPy
* Plotly

## Dataset

The dashboard works with patient data containing:

* Patient ID
* Admission Date
* Age
* Gender
* Admission Type
* Primary Diagnosis
* Length of Stay
* Comorbidity Index
* Readmission Status

## How to Run

### Install the required packages

```bash
pip install -r requirements.txt
```

### Run the application

```bash
streamlit run EHR.py
```

The dashboard will open automatically in your web browser.

## Project Structure

```text
EHR_Dashboard_Project/
│── EHR.py
│── requirements.txt
│── README.md
│── sample_ehr_data.csv
│── screenshots/
```

## Future Improvements

* Add more healthcare charts
* Include data filters
* Export reports
* Connect with a database

## Conclusion

This project demonstrates the use of Python for healthcare data analysis and dashboard development. It provides an easy way to visualize patient information and readmission trends using interactive charts and tables.
